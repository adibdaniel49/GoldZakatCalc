package com.example.goldzakatcalc;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etWeight, etValuePerGram;
    RadioGroup rgType;
    RadioButton rbKeep, rbWear;
    Button btnCalculate, btnReset;
    TextView tvTotalValue, tvZakatPayable, tvTotalZakat,tvZakatPayableGram;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Set up toolbar
        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);


        // Apply window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Link views
        etWeight = findViewById(R.id.etWeight);
        etValuePerGram = findViewById(R.id.etValuePerGram);
        rgType = findViewById(R.id.rgType);
        rbKeep = findViewById(R.id.rbKeep);
        rbWear = findViewById(R.id.rbWear);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnReset = findViewById(R.id.btnReset);
        tvTotalValue = findViewById(R.id.tvTotalValue);
        tvZakatPayable = findViewById(R.id.tvZakatPayable);
        tvTotalZakat = findViewById(R.id.tvTotalZakat);
        tvZakatPayableGram = findViewById(R.id.tvZakatPayableGram);

        // Set calculate button listener
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculateZakat();
            }
        });

        //reset
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetForm();
            }
        });


    }

    private void calculateZakat() {

        // --- Input Validation ---
        if (etWeight.getText().toString().trim().isEmpty()) {
            etWeight.setError("Please enter gold weight");
            return;
        }

        if (etValuePerGram.getText().toString().trim().isEmpty()) {
            etValuePerGram.setError("Please enter gold value per gram");
            return;
        }

        if (!rbKeep.isChecked() && !rbWear.isChecked()) {
            Toast.makeText(this, "Please select gold type", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double weight = Double.parseDouble(etWeight.getText().toString());
            double valuePerGram = Double.parseDouble(etValuePerGram.getText().toString());
            double nisab,payablegold;

            // Determine nisab (X value)
            if (rbKeep.isChecked()) {
                nisab = 85;   // keep
            } else {
                nisab = 200;  // wear
            }

            // 1. Total value of gold
            double totalValue = weight * valuePerGram;

            // 2. Gold weight after nisab (W - X)
            double uruf = weight - nisab;

            if (uruf < 0)
            {
                payablegold = 0;
            }
            else
            {
                payablegold = uruf;
            }

            // If uruf is negative, zakat payable = 0
            double zakatPayableValue = (uruf > 0) ? uruf * valuePerGram : 0;

            // 3. Total zakat = 2.5% of zakat payable value
            double totalZakat = zakatPayableValue * 0.025;

            // Display results
            tvZakatPayableGram.setText(String.format("%.2f", payablegold )+ " g");
            tvTotalValue.setText("RM " + String.format("%.2f", totalValue));
            tvZakatPayable.setText("RM " + String.format("%.2f", zakatPayableValue));
            tvTotalZakat.setText("RM " + String.format("%.2f", totalZakat));


        } catch (Exception e) {
            Toast.makeText(this, "Invalid input. Please enter valid numbers.", Toast.LENGTH_SHORT).show();
        }
    }


    // Inflate menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    // Menu item clicks
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int selected = item.getItemId();

        if (selected == R.id.menuAbout) {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;

        } else if (selected == R.id.menuShare) {
            shareApp();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //share function
    private void shareApp() {
        String appUrl = "https://github.com/we" + getPackageName();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Check out this app!");
        intent.putExtra(Intent.EXTRA_TEXT, "Download the app here:\n" + appUrl);

        startActivity(Intent.createChooser(intent, "Share via"));
    }

    //reset function
    private void resetForm() {
        etWeight.setText("");
        etValuePerGram.setText("");
        rgType.clearCheck();
        tvTotalValue.setText("RM 0.00");
        tvZakatPayableGram.setText("0.00 g");
        tvZakatPayable.setText("RM 0.00");
        tvTotalZakat.setText("RM 0.00");
    }



}
